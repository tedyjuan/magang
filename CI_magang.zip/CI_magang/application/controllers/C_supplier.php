<?php
defined('BASEPATH') or exit('No direct script access allowed');

class C_supplier extends CI_Controller
{
    public function __construct()
        { 
            parent:: __construct();
            $this->load->model('M_global');
        }

    public function index()
    {
        $data['title'] = "Data Kategori Title";
        // $this->load->view('template/index',$data);
        $this->load->view('V_supplier/Home_supplier',$data);
        $this->load->view('V_supplier/supplier_ajax');
    }

    // fungsi menampilkan all data dari database
    function Allgrid(){
        $data=$this->M_global->GridData('tbl_supplier')->result();
        echo json_encode($data);
        
    }

    // fungsi menambahkan data ke database
    function TambahData(){
        $id_supplier = $this->input->post('id_supplier');
        $nm_supplier = $this->input->post('nm_supplier');
        $alamat = $this->input->post('alamat');
        $telpon = $this->input->post('telpon');
        // validasi
        if($nm_supplier==''){
            $result ['pesan']="nama supplier harus di isi";
        }elseif ($alamat =='') {
            $result ['pesan']="Alamat supplier harus di isi";
        }elseif ($telpon =='') {
            $result ['pesan']="Telpon supplier harus di isi";
        }else {
            $result ['pesan']="";

            $data =array(
                'nm_supplier' => $nm_supplier,
                'alamat' => $alamat,
                'telpon' => $telpon
            );
            $this->M_global->tambahData($data, 'tbl_supplier');
            // variabel $data itu dari variabel array
        }
        echo json_encode($result);
    }

    // berfungsi mengambil data kedalam form berdasarkan id
    function updateid(){
        $id = $this->input->post('id_supplier');
        $where = array( 'id_supplier' => $id);
        $data = $this->M_global->update_by_id('tbl_supplier',$where)->result();
        echo json_encode($data);
        // berfungsi sebagai aksi pemrosesan menupdate dan menyimpan ke database
    }
    function Update(){
        $id_supplier = $this->input->post('id_supplier');
        $nm_supplier = $this->input->post('nm_supplier');
        $alamat = $this->input->post('alamat');
        $telpon = $this->input->post('telpon');
        // validasi
        if($nm_supplier==''){
            $result ['pesan']="nama supplier harus di isi";
        }elseif ($alamat=='') {
            $result ['pesan']="Alamat harus di isi";
        }elseif ($telpon=='') {
            $result ['pesan']="Telpon harus di isi";
        }else {
            $result ['pesan']="";
            $where = array ('id_supplier' => $id_supplier );
            $data =  array(
                'nm_supplier' => $nm_supplier,
                'alamat' => $alamat,
                'telpon' => $telpon
            );
            $this->M_global->Update($where, $data, 'tbl_supplier');
            // variabel $data itu dari variabel array
        }
        echo json_encode($result);
        }

        // fungsi menghapus data berdasarkan id
        function hapusdata(){
            $id = $this->input->post('id_supplier');
            $where = array('id_supplier' => $id);
            $this->M_global->hapusData($where,'tbl_supplier');
        }


// end php
}
