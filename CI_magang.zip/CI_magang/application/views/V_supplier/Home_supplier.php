<p>
</p>
<div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Data Supplier</h6>
            </div>
            <div class="card-body">
            <button type="button" class=" btn btn-primary btn-sm" data-toggle="modal" data-target="#FormModal" onclick="submit('Add')">
            +Add
            </button>
            <p></p>
            <table class="table table-striped table-bordered" id="mydata">
                                    <thead>
                                        <tr>
                                            <th>id Supplier</th>
                                            <th>Supplier</th>
                                            <th>Alamat</th>
                                            <th>Telpon</th>
                                            <th>Action</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody id="show_data">
                                </table>
            </div>
            </div>
<!-- =========magang modal============= -->
<!-- Button trigger modal -->

        <!-- Modal -->
        <div class="modal fade" id="FormModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="exampleModalLabel">Add Supplier</h5>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <form>
            <div class="form-group">
                        <label >Nama Supplier</label>
                        <input class="form-control" name="nm_supplier" type="text"  id="nm_supplier">  
                        <label >Alamat</label>
                        <input class="form-control" name="alamat" type="text"  id="alamat"> 
                        <label >Telpon</label>
                        <input class="form-control" name="telpon" type="text" id="telpon">    
                        <input class="form-control" name="id_supplier" type="hidden" id="id_supplier" value="">    
                    </div>
                    </form>
            </div>
            <div class="modal-footer">
            <button type="button" id="btn-tambah" class="btn btn-primary btn-sm" onclick="tambahdata()">Save</button>
            <button type="button" id="btn-Update" class="btn btn-primary btn-sm" onclick="Update()">Update</button>
            <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
            </div>
            </div>
        </div>
        </div>
<!-- ==============end magang modal========= -->
            