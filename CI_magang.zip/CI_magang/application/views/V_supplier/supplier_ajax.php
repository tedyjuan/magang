<script type="text/javascript">
    $(document).ready(function(){
        // datatabel
        $('#mydata').dataTable();
    });


// grid data untuk memnagil fungsi langsung
GridData();
function GridData(){
        $.ajax({
            type: 'ajax',
            url: '<?php echo base_url()."index.php/C_supplier/Allgrid"?>',
            dataType: 'json',
            async: false,
            success : function(data){
                var baris ='';
                var i;
                for (var i=0; i<data.length; i++){
                    baris +='<tr>'+
                                '<td>'+data[i].id_supplier+' </td>'+
                                '<td>'+data[i].nm_supplier+' </td>'+
                                '<td>'+data[i].alamat+' </td>'+
                                '<td>'+data[i].telpon+' </td>'+
                                '<td><a href="#FormModal" data-toggle="modal" class="btn btn-primary btn-sm " onclick="submit('+data[i].id_supplier+')">Update</a><a  class="btn btn-danger btn-sm text-white   " onclick="hapusData('+data[i].id_supplier+')">Delete</a></td>'+
                            '</tr>';
                            // untuk tombol update itu disisipkan id jadi submit(isi dengan id)
                        // data togle memangil modal dan href nya ke form modalnya
                }
                $('#show_data').html(baris);
            }
        });
    };

    // fungsi untuk menambahkan data dan fungsi ini di kirim ke tombol Add
    function tambahdata(){
        var id_supplier =$("[name='id_supplier']").val();
        var nm_supplier =$("[name='nm_supplier']").val();
        var alamat =$("[name='alamat']").val();
        var telpon =$("[name='telpon']").val();
        
        $.ajax({
            type: 'POST',
            data: 'id_supplier='+id_supplier+'&nm_supplier='+nm_supplier+'&alamat='+alamat+'&telpon='+telpon,
            url : '<?php echo base_url().'index.php/C_supplier/TambahData'?>',
            dataType :'json',
            success : function(hasil){
                $("#pesan").html(hasil.pesan);
                if(hasil.pesan==''){
                    $("#FormModal").modal('hide');
                    GridData();
                    $("[name='id_supplier']").val('');
                    $("[name='nm_supplier']").val('');
                    $("[name='alamat']").val('');
                    $("[name='telpon']").val('');
                }
            
            }
        });
    }
    
    // fungsi menampilkan tombol update dan save
    function submit(x){
        if(x=='Add'){
            $("#btn-tambah").show();
            $("#btn-Update").hide();
        }else{
            $("#btn-tambah").hide();
            $("#btn-Update").show();

            $.ajax({
                type: "POST",
                // data : harus sesuai dengan id pada <input> id 
                data : 'id_supplier='+x,
                url:'<?php echo base_url()."index.php/C_supplier/updateid" ?>',
                dataType : 'json',
                success : function(hasil){
                    // console.log(hasil);
                    // fungsi menampilkan data di form update
                    $("[name='id_supplier']").val(hasil[0].id_supplier);
                    $("[name='nm_supplier']").val(hasil[0].nm_supplier);
                    $("[name='alamat']").val(hasil[0].alamat);
                    $("[name='telpon']").val(hasil[0].telpon);
                    
                }
            });
        }
    }

    // fungsi mengubah/update data dan menyimpan ke database
    function Update(){
        var id_supplier =$("[name='id_supplier']").val();
        var nm_supplier =$("[name='nm_supplier']").val();
        var alamat      =$("[name='alamat']").val();
        var telpon      =$("[name='telpon']").val();
        $.ajax({
            type: "POST",
            data : 'id_supplier='+id_supplier+'&nm_supplier='+nm_supplier+'&alamat='+alamat+'&telpon='+telpon,
            url : '<?php echo base_url().'index.php/C_supplier/Update'?>',
            dataType : 'json',
            success : function(hasil){
                $("#pesan").html(hasil.pesan);
                if(hasil.pesan==''){
                    $("#FormModal").modal('hide');
                    GridData();
                    $("[name='id_supplier']").val('');
                    $("[name='nm_supplier']").val('');
                    $("[name='alamat']").val('');
                    $("[name='telpon']").val('');
                }
            
            }
        });
    }

    // berfungsi menghapus data berdasarkan id 
    function hapusData(id){
        var tanya = confirm('apakah anda yakin menghapus data ini');
        if( tanya ){
            $.ajax({
                type:'POST',
                data : 'id_supplier='+id,
                url : '<?php echo base_url()."index.php/C_supplier/hapusdata"?>',
                success : function (){
                    GridData();
                }

            });
        }

    }

    
</script>

