<?php defined ('BASEPATH') or exit();

class M_global extends CI_Model
{
    /* global data berfungsi menampung segala fungsi perintah 
        CRUD =  C:CREAT membuat
                R:READ membaca
                U:UPDATE merubah
                D:DELETE menghapus
    
    */

    // fungsi menampilkan all data tabel
    function GridData($table){
        return $this->db->get($table);
    }

    // fungsi menambahkan data ke database
    function tambahData($data,$table){
        return $this->db->insert($table, $data);

    }

    // fungsi mengambil field/rows berdasarkan id
    function update_by_id($table,$where){
        return $this->db->get_where($table,$where);
    }
//  berfungsi proses update berdasarkan id
    function Update($where,$data,$table){
        $this->db->where($where);
        $this->db->update($table,$data);
    }

    function hapusData($where,$table){
        $this->db->where($where);
        $this->db->delete($table);
    }
}